const images = {
  imgThumbWidth: 185,
  imgThumbHeight: 100,
  imgLargerWidth: 185,
  imgLargerHeight: 100,
  logo: require('../assets/images/logo.png'),
  homeSlider: [
    require('../assets/images/slider/slide.png'),
    require('../assets/images/slider/slide.png'),
    require('../assets/images/slider/slide.png'),
  ],
};

export default images

