export const ActionTypes = {
    SET_USER_LOGIN: 'SET_USER_LOGIN',
    SET_CART: 'SET_CART',
    SET_YEU_THICH: 'SET_YEU_THICH',
}